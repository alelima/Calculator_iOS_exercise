//
//  InstaTableViewCell.swift
//  AutoLayoutExercicio
//
//  Created by Alessandro on 18/04/18.
//  Copyright © 2018 nitrox. All rights reserved.
//

import UIKit

class InstaTableViewCell: UITableViewCell {
    
    @IBOutlet weak var perfilImageView: UIImageView!
    
    @IBOutlet weak var userNameLabel: UILabel!
    
    @IBOutlet weak var functionButton: UIButton!
    
    @IBOutlet weak var pictureImageView: UIImageView!
    
    @IBOutlet weak var heartButton: UIButton!
    
    @IBOutlet weak var commentButton: UIButton!
    
    @IBOutlet weak var shareButton: UIButton!
    
    @IBOutlet weak var likesLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(with post:InstaPost) {
        self.perfilImageView.image = post.perfilImage
        self.userNameLabel.text = post.userName
        self.pictureImageView.image = post.pictureImagem
        self.likesLabel.text = String("\(post.numberOfLikes!) ♥︎ Likes")
    }

}
