//
//  InstaPost.swift
//  AutoLayoutExercicio
//
//  Created by Alessandro on 18/04/18.
//  Copyright © 2018 nitrox. All rights reserved.
//

import Foundation
import UIKit

struct InstaPost {
    
     var userName:String?
     var perfilImage: UIImage?
     var pictureImagem: UIImage?
     var numberOfLikes: Int?
    
}
