//
//  InstaTableViewController.swift
//  AutoLayoutExercicio
//
//  Created by Alessandro on 18/04/18.
//  Copyright © 2018 nitrox. All rights reserved.
//

import UIKit

class InstaTableViewController: UITableViewController {
    
    var posts: [InstaPost] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        for _ in 0...20 {
            posts.append(createInstaPosts())
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func createInstaPosts() -> InstaPost {
        var post = InstaPost()
        post.numberOfLikes = 20
        post.userName = "alelima"
        post.perfilImage = #imageLiteral(resourceName: "perfil")
        post.pictureImagem = #imageLiteral(resourceName: "foz")
        
        return post
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return posts.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "instaCell", for: indexPath) as! InstaTableViewCell

        cell.configure(with: posts[indexPath.row])

        return cell
    }

}
